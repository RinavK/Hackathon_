#include <iostream>
#include <vector>
#include <string>
using namespace std;

//Declaring Our global variables
vector<string> patients;
vector<string> patientStatus;


void addPatients() {
	string name;
  string condition;
	cout << "What is the name of the patient you would like to add?" << endl;
	cin >> name;
	patients.push_back(name);
  cout << "What is their status: Sick or Healthy?" << endl;
  cin >> condition;
  patientStatus.push_back(condition);
  cout << "You now have " << name << " in your care and they are " << condition << "." << endl;
	cout << "You now have " << patients.size() << " patients in your care." << endl;
}

void removePatients() {
  int i;
  int patientNum;
	cout << "Which patient would you like to remove from the list? Enter their number: ";
  for (i = 0; i < patients.size(); i++) {
    cout << endl << patients[i] << ": " << patientStatus[i] << " " << endl;
  }
  cin >> patientNum;
  patients.erase(patients.begin() + patientNum - 1);
  cout << "Here are your remaining patients" << endl;
  for (i = 0; i < patients.size(); i++) {
    cout << endl << patients[i] << " " << endl;
  }
}

void changePatients() {
  int i;
  int change;
  string change1;
	cout << "Here are your patients: " << endl;
  for (i = 0; i < patients.size(); i++) {
    cout << endl << patients[i] << ": " << patientStatus[i] << " " << endl;
  }
  cout << endl << "Which number patient's status would you like to change?" << endl;
  cin >> change;
  patientStatus.erase(patientStatus.begin() + change - 1);
  cout << "What would like to change their status to?" << endl;
  cin >> change1;
  patientStatus.insert(patientStatus.begin() + change - 1, change1);
  cout << patients[change - 1] << " is now " << change1 << "." << endl;
}


void displayPatients() {
  int i;
  for (i = 0; i < patients.size(); i++) {
    cout << endl << patients[i] << ": " << patientStatus[i] << " " << endl;
  }
}

int main() {
  int one = 1;
  int two = 2;
  while(one < two) {
    string option;
    cout << "\n What would you like to do:" << endl;
      cout << "A. Add a patient " << endl << "B. Remove a patient" << endl << "C. Adjust a patient's status" << endl << "D. View your patients" << endl;
    cin >> option;
    if (option == "A"){
      addPatients();
    }
    if (option == "B") {
      removePatients();
    }
    if (option == "C") {
      changePatients();
    }
    if (option == "D") {
      displayPatients();
    }
  }

  return 0;
}
